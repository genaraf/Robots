package com.remote.yingwen.carhttp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	private static final String ACTION = "com.jk184.car.action.NEW_FILE";
	private static final String ACTION_FINISH = "com.jk184.car.action.UPLOAD_FINISH";
	private Button but_center;
	private Button but_left;
	private Button but_right;
	private Button but_up;
	private Button but_below;
	private Button but_r_speenUp;
	private Button but_l_speenUp;
	private Button but_r_slowDown;
	private Button but_l_slowDown;
	private TextView tv_device_id;
	private TextView tv_d_online;
	static private final String SETTINGS = "DEVICE_ID";
	private TextView title;
	public static String device_id;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		initView();

		Intent serviceIntent = new Intent();
		serviceIntent.setAction("com.remote.yingwen.carhttp.service");
		startService(serviceIntent);

		IntentFilter filter = new IntentFilter(ACTION_FINISH);
		registerReceiver(this.UploadList, filter);

		SharedPreferences setting = getSharedPreferences(SETTINGS, 0);
		device_id = setting.getString("DEVICE_ID", null);
		if (device_id == null) {
			setDeviceID();
		}
	}

	private void saveUserID(String str) {
		SharedPreferences settings = getSharedPreferences(SETTINGS, 0);
		settings.edit().putString("DEVICE_ID", str).commit();
	}

	private void setDeviceID() {
		final EditText et = new EditText(MainActivity.this);
		et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(7)});//限制7个字符
		new AlertDialog.Builder(MainActivity.this).setTitle("Input Device ID")
				.setView(et)
				.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {

						String str = et.getText().toString();
						if (str.length() > 0) {
							saveUserID(str);
							device_id = str;
							saveDeviceID(device_id);
							tv_device_id.setText("Device ID:"+device_id);
						} else {
							Toast.makeText(getApplicationContext(), "Device ID can not be empty!",
									Toast.LENGTH_LONG).show();
						}

					}
				}).setNegativeButton("Cancel", null).show();
	}
	
	private final BroadcastReceiver UploadList = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			String dolres = intent.getStringExtra("DOLRES");
			String str = intent.getStringExtra("RESULT");
			if(dolres.equals("0")){
				tv_d_online.setText("Device is not online");
			}else{
				tv_d_online.setText(dolres+"devices connected to the platform");
			}
			
			if (str.equals("1")) {
				title.setText("Send success");
			}

			if (str.equals("-1")) {
				title.setText("Send failed");
			}

			if (str.equals("-2")) {
				finish();
			}
			
		}
	};

	public void initView() {
		but_center = (Button) findViewById(R.id.but_center);
		but_left = (Button) findViewById(R.id.but_left);
		but_right = (Button) findViewById(R.id.but_right);
		but_up = (Button) findViewById(R.id.but_up);
		but_below = (Button) findViewById(R.id.but_below);
		but_l_slowDown = (Button) findViewById(R.id.but_l_slowDown);
		but_r_slowDown = (Button) findViewById(R.id.but_r_slowDown);
		but_l_speenUp = (Button) findViewById(R.id.but_l_speenUp);
		but_r_speenUp = (Button) findViewById(R.id.but_r_speenUp);
		tv_device_id = (TextView) findViewById(R.id.tv_device_id);
		tv_d_online = (TextView) findViewById(R.id.tv_d_online);
		title = (TextView) findViewById(R.id.title);

		but_center.setOnClickListener(this);
		but_left.setOnClickListener(this);
		but_right.setOnClickListener(this);
		but_up.setOnClickListener(this);
		but_below.setOnClickListener(this);
		but_l_slowDown.setOnClickListener(this);
		but_r_slowDown.setOnClickListener(this);
		but_l_speenUp.setOnClickListener(this);
		but_r_speenUp.setOnClickListener(this);
		tv_device_id.setOnClickListener(this);

		SharedPreferences sp = getSharedPreferences("DeviceID", 0);
		tv_device_id.setText("Device ID:"+sp.getString("Id", ""));
	}

	@Override
	public void onClick(View v) {
		if(isNetworkAvailable(MainActivity.this)){
			switch (v.getId()) {
			case R.id.but_center:
				send("0");
				break;
			case R.id.but_left:
				send("3");
				break;
			case R.id.but_right:
				send("4");
				break;
			case R.id.but_up:
				send("1");
				break;
			case R.id.but_below:
				send("2");
				break;
			case R.id.but_l_speenUp:
				send("6");
				break;
			case R.id.but_r_speenUp:
				send("8");
				break;
			case R.id.but_l_slowDown:
				send("7");
				break;
			case R.id.but_r_slowDown:
				send("9");
				break;
			case R.id.tv_device_id:
				setDeviceID();
				break;
	
			default:
				break;
			}
		}else{
			Toast.makeText(MainActivity.this, "The network is not available", 5).show();
		}
	}

	private void send(String str) {
		Intent intentAddFile = new Intent(ACTION);
		intentAddFile.putExtra("TYPE", str);
		sendBroadcast(intentAddFile);
	}

	public void onDestroy() {
		super.onDestroy();
		unregisterReceiver(UploadList);

		Intent serviceIntent = new Intent();
		serviceIntent.setAction("com.remote.yingwen.carhttp.service");
		stopService(serviceIntent);

	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			new AlertDialog.Builder(this)
					.setIcon(R.drawable.ic_launcher)
					.setTitle("Exit")
					.setNegativeButton("Cancel",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {

								}
							})
					.setPositiveButton("OK",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int whichButton) {

									finish();
								}
							}).show();

			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * 保存设备id
	 * @param s
	 */
	public void saveDeviceID(String s) {
		Context ctx = MainActivity.this;
		SharedPreferences sp = ctx.getSharedPreferences("DeviceID",
				MODE_PRIVATE);
		Editor editor = sp.edit();
		editor.putString("Id", s);
		editor.commit();
	}
	
	/**
	 * 判断网络是否可用
	 * @param activity
	 * @return
	 */
	public boolean isNetworkAvailable(Activity activity)
    {
        Context context = activity.getApplicationContext();
        // 获取手机所有连接管理对象（包括对wi-fi,net等连接的管理）
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        
        if (connectivityManager == null)
        {
            return false;
        }
        else
        {
            // 获取NetworkInfo对象
            NetworkInfo[] networkInfo = connectivityManager.getAllNetworkInfo();
            
            if (networkInfo != null && networkInfo.length > 0)
            {
                for (int i = 0; i < networkInfo.length; i++)
                {
                    // 判断当前网络状态是否为连接状态
                    if (networkInfo[i].getState() == NetworkInfo.State.CONNECTED)
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }
} 

