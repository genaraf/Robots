package com.remote.yingwen.carhttp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;

@SuppressLint("HandlerLeak")
public class UploadFileService extends Service {
	private static final String ACTION = "com.jk184.car.action.NEW_FILE";
	private static final String ACTION_FINISH = "com.jk184.car.action.UPLOAD_FINISH";
	private HandleThread thread;
	static public List<Map<String, Object>> data = new ArrayList<Map<String, Object>>();
	private String type = null;

	public static final String IP = "http://182.92.178.210/api.php?topic=";
	public static final String IP2 = "http://182.92.178.210/num.php?topic=";

	public IBinder onBind(Intent intent) {
		return null;
	}

	public void onCreate() {
		super.onCreate();
		IntentFilter filter = new IntentFilter(ACTION);
		registerReceiver(this.UploadReceiver, filter);

		thread = new HandleThread();
		thread.start();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();

		unregisterReceiver(this.UploadReceiver);

		thread.requestExit();

	}

	private final BroadcastReceiver UploadReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			String path = intent.getStringExtra("TYPE");

			Map<String, Object> item = new HashMap<String, Object>();
			item.put("TYPE", path);

			synchronized (data) {
				data.add(item);
				data.notify();
			}
		}
	};

	private void initFileInfo(Map<String, Object> cache) {

		type = (String) cache.get("TYPE");
	}

	private void noticeUploadList(String str, String dolres) {

		Intent intent1 = new Intent(ACTION_FINISH);
		intent1.putExtra("RESULT", str);
		intent1.putExtra("DOLRES", dolres);
		sendBroadcast(intent1);

	}

	private class HandleThread extends Thread {
		private String res;
		private String dolres; // 查询设备连接状态结果
		private Map<String, Object> cache = null;
		private boolean bRun = true;

		public void requestExit() {
			bRun = false;
			synchronized (data) {
				data.notify();
			}
		}

		/**
		 * 定时刷新连接状况
		 */
		private void UpDOL(){
			 Timer timer = new Timer();  
			 timer.schedule(new TimerTask() {
				 
				@Override
				public void run() {
					dolres = dOnline();
					noticeUploadList("0", dolres);
				}
			}, 0,1000);
		}
		
		public String dOnline() {
			String res = null;
			try {
				MyHttp myDol = new MyHttp(IP2 + MainActivity.device_id);
				res = myDol.httpPost();
			} catch (Exception e) {
				return null;
			}
			return res;
		}

		public String send(String str) {
			String res = null;
			try {
				MyHttp myAds = new MyHttp(IP + MainActivity.device_id
						+ "&message=" + str);
				res = myAds.httpPost();
			} catch (Exception e) {
				res = null;
			}
			return res;

		}

		public void run() {
			UpDOL();
			while (bRun) {

				synchronized (data) {
					if (data.size() > 0) {
						cache = data.get(0);
					} else {
						try {
							data.wait();
						} catch (InterruptedException e) {
							Log.d("data", "data.wait");
						}
						continue;
					}
				}
				if (cache != null) {
					initFileInfo(cache);
					cache = null;

					res = send(type);
					// 这里注意返回值看是“ok”还是“ok\r\n”
					if (res.equals("ok\r\n")) {
						data.remove(0);
						noticeUploadList("1", dolres);
					} else {
						data.remove(0);
						noticeUploadList("-1", dolres);
					}
				}
			}
		}
	}

}
