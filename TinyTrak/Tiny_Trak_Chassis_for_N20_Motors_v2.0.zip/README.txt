                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2980703
Tiny Trak Chassis for N20 Motors v2.0 by MelihKa is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is the second generation body design of my TinyTrak 
(v1.0 here: https://www.thingiverse.com/thing:2930903 )


Tiny Trak is a Lego rubber treads based micro rc tank.
Please join our facebook group for more information and ideas.
https://www.facebook.com/groups/181517579149618/

I've designed the chassis for N20 motors which is easy to find geared low voltage motors.

You can find different gear ratios on eBay. 

I'm using 6v 300rpm motors with 1S (3.7volts) Lipo battery.

For the freewheels, I've cut the original lego axles and glue it in their place using CA.

In the current design, I'm using my own WiMo v1.0 Wifi motor driver board and control the tank over the free RCWController app. You can also use RC receiver and brushed ESC to drive the motors.

I've used 2mm thick, 3mm diameter Neodium magnets to attach the top part. You can push the magnets to the holes or glue with CA. 

Unfortunately, my hard disk crashed and I've lost my all Cura profiles last week. So, I've used Makerware software and default ABD profile to print 0.3mm layer thickness for a fast test prototype. This is why my end results are really poor.